PARTIAL SOUND PACK — 13 WAV files

All audio is from Kenney CC0 packs. No movie recordings included.
Audio was decoded and checked for decode errors, but not auditioned here.
Check the musical cues in-game before deciding to replace existing sounds.

Substitutions:
- door-open: door-opening recording
- open-wood: wooden-door recording used as a chest/wardrobe-opening substitute
- knock: single wooden impact used as a knock
- smash: wood impact substitute; no pumpkin crunch
- soul: short steel musical cue substitute
- pumpkin-found: short steel musical reveal cue substitute
- win: short pizzicato musical cue

Missing (retain current game sounds):
amb-house
amb-cellar
amb-lake
whisper
scream
amb-chapel
breath
heartbeat
gasp
zombie-step
relight
phone-ring
tv-static
music-box
splash
sting
drumroll
lose
voice-michael
voice-samara
voice-valak
voice-annabelle

Freesound and Pixabay returned HTTP 403 from this environment.
Original pack licences and one source-credit line per sound are included.
